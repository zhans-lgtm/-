const form = document.getElementById("expenseForm");
const typeInput = document.getElementById("type");
const amountInput = document.getElementById("amount");
const categoryInput = document.getElementById("category");
const descriptionInput = document.getElementById("description");
const dateInput = document.getElementById("date");
const history = document.getElementById("history");

function localDate() {
    const today = new Date();
    return [
        today.getFullYear(),
        String(today.getMonth() + 1).padStart(2, "0"),
        String(today.getDate()).padStart(2, "0")
    ].join("-");
}

dateInput.value = localDate();

let operations = [];

try {
    const saved = JSON.parse(
        localStorage.getItem("myFinance") || "[]"
    );

    if (Array.isArray(saved)) {
        operations = saved.filter(item =>
            item &&
            typeof item.amount === "number" &&
            Number.isFinite(item.amount) &&
            item.amount > 0 &&
            ["income", "expense"].includes(item.type) &&
            typeof item.date === "string" &&
            typeof item.category === "string"
        );
    }
} catch {
    operations = [];
}

function money(amount) {
    return amount.toLocaleString("kk-KZ", {
        maximumFractionDigits: 2
    }) + " ₸";
}

function saveData() {
    localStorage.setItem(
        "myFinance",
        JSON.stringify(operations)
    );
}

function render() {
    const income = operations
        .filter(item => item.type === "income")
        .reduce((sum, item) => sum + item.amount, 0);

    const expense = operations
        .filter(item => item.type === "expense")
        .reduce((sum, item) => sum + item.amount, 0);

    const todayExpense = operations
        .filter(item =>
            item.type === "expense" &&
            item.date === localDate()
        )
        .reduce((sum, item) => sum + item.amount, 0);

    const monthExpense = operations
        .filter(item =>
            item.type === "expense" &&
            item.date.startsWith(localDate().slice(0, 7))
        )
        .reduce((sum, item) => sum + item.amount, 0);

    document.getElementById("balance").textContent =
        money(income - expense);

    document.getElementById("income").textContent =
        money(income);

    document.getElementById("expense").textContent =
        money(expense);

    document.getElementById("todayExpense").textContent =
        money(todayExpense);

    document.getElementById("monthExpense").textContent =
        money(monthExpense);

    history.replaceChildren();

    if (operations.length === 0) {
        const empty = document.createElement("p");
        empty.className = "empty";
        empty.textContent = "Әзірге операциялар жоқ";
        history.appendChild(empty);
        return;
    }

    [...operations]
        .sort((a, b) => b.date.localeCompare(a.date))
        .forEach(item => {
            const row = document.createElement("div");
            row.className = "history-item";

            const icon = document.createElement("div");
            icon.className = "history-icon";
            icon.textContent =
                item.type === "income" ? "↗" : "↘";

            const details = document.createElement("div");
            details.className = "history-details";

            const title = document.createElement("h4");
            title.textContent =
                item.description || item.category;

            const detail = document.createElement("p");
            detail.textContent =
                item.category + " • " + item.date;

            details.append(title, detail);

            const amount = document.createElement("div");
            amount.className =
                "history-amount " +
                (item.type === "income" ? "positive" : "negative");

            amount.textContent =
                (item.type === "income" ? "+" : "−") +
                money(item.amount);

            const deleteBtn = document.createElement("button");
            deleteBtn.className = "delete-btn";
            deleteBtn.textContent = "×";
            deleteBtn.setAttribute("aria-label", "Өшіру");

            deleteBtn.addEventListener("click", () => {
                operations = operations.filter(
                    operation => operation.id !== item.id
                );
                saveData();
                render();
            });

            row.append(icon, details, amount, deleteBtn);
            history.appendChild(row);
        });
}

form.addEventListener("submit", event => {
    event.preventDefault();

    const amount = Number(amountInput.value);

    if (!Number.isFinite(amount) || amount <= 0) {
        alert("Соманы дұрыс енгіз!");
        return;
    }

    if (!dateInput.value) {
        alert("Күнді таңда!");
        return;
    }

    operations.push({
        id: crypto.randomUUID(),
        type: typeInput.value,
        amount: amount,
        category: categoryInput.value,
        description: descriptionInput.value.trim(),
        date: dateInput.value
    });

    saveData();
    render();

    amountInput.value = "";
    descriptionInput.value = "";
    dateInput.value = localDate();
});

document.getElementById("clearBtn")
    .addEventListener("click", () => {
        if (operations.length === 0) return;

        if (confirm("Барлық операцияны өшіргің келе ме?")) {
            operations = [];
            saveData();
            render();
        }
    });

render();